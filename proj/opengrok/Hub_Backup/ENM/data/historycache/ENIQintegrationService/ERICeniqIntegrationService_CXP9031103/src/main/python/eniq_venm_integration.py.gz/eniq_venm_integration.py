<?xml version="1.0" encoding="UTF-8"?>
<java version="1.7.0_99" class="java.beans.XMLDecoder">
 <object class="org.opensolaris.opengrok.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Prashant Kumar Kadiyam &lt;prashant.kadiyam@tcs.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1573565486000</long>
      </object>
     </void>
     <void property="message">
      <string>TORF-381415 eniq_venm_integration.py script lists two pm FS for Extra Small ENM Deployment
    
    Change-Id: I57ea658a7d8f4bf98ab755fd8dd8e05c71315f99</string>
     </void>
     <void property="revision">
      <string>deb52d13</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>xsujath &lt;sujatha.k14@wipro.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1534718960000</long>
      </object>
     </void>
     <void property="message">
      <string>[TORF-289810]- Topology is not getting created when integrated after disabling symbolic links for ENIQ-Stats
    
    https://jira-nam.lmera.ericsson.se/browse/TORF-289810
    
    Change-Id: Ibd7c4cab6be807f92395ff90a1a36f24706e66ff</string>
     </void>
     <void property="revision">
      <string>80ce1a7c</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>xsujath &lt;sujatha.k14@wipro.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1533299714000</long>
      </object>
     </void>
     <void property="message">
      <string>[TORF-286786] : symbolicLinkTargetPrefixEvents PIB is not being updated as part of ENIQ Events Integration steps
    
    https://jira-nam.lmera.ericsson.se/browse/TORF-286786
    
    Change-Id: I8da08811f4c9f8c11d813635215e2820c9236610</string>
     </void>
     <void property="revision">
      <string>ea9fa7b6</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>xamaagr &lt;aman.agrahari1@wipro.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1526037721000</long>
      </object>
     </void>
     <void property="message">
      <string>[TORF-239835] :  Symlink is not created as expected.
    
    https://jira-nam.lmera.ericsson.se/browse/TORF-239835
    
    Change-Id: Ic4fdbd39682143626d6b14386a627f14588aed0d</string>
     </void>
     <void property="revision">
      <string>977bdd39</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Usha Veepuri &lt;usha.veepuri@tcs.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1512559450000</long>
      </object>
     </void>
     <void property="message">
      <string>TORF-235568 useStatsSymlinks is not shown to user with showPIBvalue command in cloud
    
    Change-Id: I4d130228f0782b55aeeb0226ddf9c5bd9d760519</string>
     </void>
     <void property="revision">
      <string>8849843b</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>xsujath &lt;sujatha.k14@wipro.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1512384184000</long>
      </object>
     </void>
     <void property="message">
      <string>TORF-234879 - Update Weekly Historic Export Input Mechanism to align with cloud
    
    https://jira-nam.lmera.ericsson.se/browse/TORF-234879
    
    Change-Id: I329afcb123999b55cdbfbf358fa326961424dcc2</string>
     </void>
     <void property="revision">
      <string>5a8dca53</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Usha Veepuri &lt;usha.veepuri@tcs.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1512028479000</long>
      </object>
     </void>
     <void property="message">
      <string>TORF-233664 Historical export is getting enabled for wrong day of the week in Cloud
    
    Change-Id: Ifc4d717b2bcff2613ef6ccc02a7ccb3dec9fccca</string>
     </void>
     <void property="revision">
      <string>ff3d47d3</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Usha Veepuri &lt;usha.veepuri@tcs.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1509042800000</long>
      </object>
     </void>
     <void property="message">
      <string>TORF-202843 Integration script for ENIQ to vENM
    
    Change-Id: I0f1eccb65334a8e5cf30b69df0d92eec0916bacd</string>
     </void>
     <void property="revision">
      <string>53f88a59</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
