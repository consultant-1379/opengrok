<?xml version="1.0" encoding="UTF-8"?>
<java version="1.7.0_99" class="java.beans.XMLDecoder">
 <object class="org.opensolaris.opengrok.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>eeoiobr &lt;eoin.o.brien@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1453454639000</long>
      </object>
     </void>
     <void property="message">
      <string>TORF-95087 refactor PyUNit tests
    
    Change-Id: I8741367bc9da6a022457c570403e8b058a0634b5</string>
     </void>
     <void property="revision">
      <string>792f972c</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>eeoiobr &lt;eoin.o.brien@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1423151787000</long>
      </object>
     </void>
     <void property="message">
      <string>TORF 36863 Take in more than one IP address and share out
    
    Change-Id: I4acbac7daa4cfab12938c6ca9d8937dadfd4ea21</string>
     </void>
     <void property="revision">
      <string>3ebb8a05</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>eeoiobr &lt;eoin.o.brien@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1422007213000</long>
      </object>
     </void>
     <void property="message">
      <string>Allow for Events Alias
    
    Change-Id: I2f563d94b4913e61eb07b57c0e5d5f32e6c9fc07</string>
     </void>
     <void property="revision">
      <string>cdadc2d3</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>eeoiobr &lt;eoin.o.brien@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1412755101000</long>
      </object>
     </void>
     <void property="message">
      <string>Moving Tests to Test folder
    
    Change-Id: I92f3506570913e5ccf5019ca2b3483b4bab25b3a</string>
     </void>
     <void property="revision">
      <string>b8fc2ab8</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
