<?xml version="1.0" encoding="UTF-8"?>
<java version="1.7.0_99" class="java.beans.XMLDecoder">
 <object class="org.opensolaris.opengrok.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>eeipca &lt;paul.carroll@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1516381721000</long>
      </object>
     </void>
     <void property="message">
      <string>TORF-227131
    As an installation engineer I want to run a script to ensure rack server will PXE boot, so that I with confidence can start an install/upgrade/expansion
    https://jira-nam.lmera.ericsson.se/browse/TORF-227131
    
    Change-Id: I7a30e5892ec44814d36c35f13b4b250b69b24be8</string>
     </void>
     <void property="revision">
      <string>841a5b52</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>eeipca &lt;paul.carroll@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1471008870000</long>
      </object>
     </void>
     <void property="message">
      <string>TORF-139313: HV16731 AT&amp;T ENM 16.10: ENM healthcheck script failing when one physical node is down.
    https://jira-nam.lmera.ericsson.se/browse/TORF-139313
    
    Change-Id: I502aa527c354bcd8f7b0faa647405985565f242d</string>
     </void>
     <void property="revision">
      <string>4784c17a</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>eeipca &lt;paul.carroll@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1457586309000</long>
      </object>
     </void>
     <void property="message">
      <string>[TORF-81994] Remove ALL pylint errors/warnings from ENM_INST
    http://jira-nam.lmera.ericsson.se/browse/TORF-81994
    
    Change-Id: I489e88ab771457702a5da3b941259c169f8b2d75</string>
     </void>
     <void property="revision">
      <string>171523b5</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
