<?xml version="1.0" encoding="UTF-8"?>
<java version="1.7.0_99" class="java.beans.XMLDecoder">
 <object class="org.opensolaris.opengrok.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>ekanpio &lt;piotr.kania@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1434112262000</long>
      </object>
     </void>
     <void property="message">
      <string>TORF-60033 Added encryption of clear text passwords read from SED in Python,
    Added generation of temporary property file to store generated properties only,
    Extended substitute_parameters  procedure to handle  &apos;----propertyfile filename&apos; argument
    to read additional properties.
    substitute_parameters module read variables from original SED file
    and from additional generated SED file and replace those variables in template file.
    Added separate logging configuration.
    Fixed problem with test_init_enminst_logging_no_config_file
    which fails if ENMInst is already installed
    
    Change-Id: Id64e2c61f5a86fc10cb6e2a1e038695fb764d8b5</string>
     </void>
     <void property="revision">
      <string>0b5feb6e</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
