<?xml version="1.0" encoding="UTF-8"?>
<java version="1.7.0_241" class="java.beans.XMLDecoder">
 <object class="org.opensolaris.opengrok.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Aram Rassool &lt;aram.rassool@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1597668144000</long>
      </object>
     </void>
     <void property="message">
      <string>TORF-392599 AP: ENM Application Fileshare: Auto Provisioning to cease using NFS location /ericsson/tor/data
    
    Story: https://jira-oss.seli.wh.rnd.internal.ericsson.com/browse/TORF-392599
    
    DA: https://confluence-oss.seli.wh.rnd.internal.ericsson.com/x/bxgjFg
    
    Change-Id: I3f3cfad7cd4ea37fb49a7f701fe220802bed8738</string>
     </void>
     <void property="revision">
      <string>cfddad67</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
