<?xml version="1.0" encoding="UTF-8"?>
<java version="1.7.0_241" class="java.beans.XMLDecoder">
 <object class="org.opensolaris.opengrok.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Aram Rassool &lt;aram.rassool@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1597668144000</long>
      </object>
     </void>
     <void property="message">
      <string>TORF-392599 AP: ENM Application Fileshare: Auto Provisioning to cease using NFS location /ericsson/tor/data
    
    Story: https://jira-oss.seli.wh.rnd.internal.ericsson.com/browse/TORF-392599
    
    DA: https://confluence-oss.seli.wh.rnd.internal.ericsson.com/x/bxgjFg
    
    Change-Id: I3f3cfad7cd4ea37fb49a7f701fe220802bed8738</string>
     </void>
     <void property="revision">
      <string>cfddad67</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>eeiwdey &lt;wayne.delaney@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1575976325000</long>
      </object>
     </void>
     <void property="message">
      <string>[TORF-384675] [CM Audit Service] Create new cellserv SG
    https://jira-oss.seli.wh.rnd.internal.ericsson.com/browse/TORF-384675
    
    Change-Id: I94a627f0abc87f4d1d13e6a0f0b9fb2a4cde5372</string>
     </void>
     <void property="revision">
      <string>44a3aaf9</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>ZANIARI &lt;arindam.animesh@tcs.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1553193921000</long>
      </object>
     </void>
     <void property="message">
      <string>[TORF-330276] [Cell Mgmt] Export TrackerFiles should be cleaned on SFS
    https://jira-nam.lmera.ericsson.se/browse/TORF-330276
    
    Change-Id: Iae054de812fcc9a2b9f6ad075b4c7240a824c74a</string>
     </void>
     <void property="revision">
      <string>c1f137c0</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Hugo Hernandez &lt;hugo.h.hernandez@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1550145247000</long>
      </object>
     </void>
     <void property="message">
      <string>TORF-320873 Full KGBN jobs failing apserv
    
    Change-Id: Id5b9ad88132d8674ba87d030308a76b839ee2b5e</string>
     </void>
     <void property="revision">
      <string>a97e0b89</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>eaajssa &lt;anuj.f.sharma@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1533836769000</long>
      </object>
     </void>
     <void property="message">
      <string>TORF-276577 APServ Memory Tuning
    
    Change-Id: Ic40cef273c9316a9222ffa02368d5a26e77906df</string>
     </void>
     <void property="revision">
      <string>96ddd524</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>xvishsr &lt;vishal.srivastava5@tcs.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1516203198000</long>
      </object>
     </void>
     <void property="message">
      <string>TORF-242369 : Create CM directory in AutoProvisioning Service Group (postinstall)
    https://jira-nam.lmera.ericsson.se/browse/TORF-242369
    
    Change-Id: Idd29aa35ecbecd4ba4d6580c256984afc5c2d846</string>
     </void>
     <void property="revision">
      <string>18972fa0</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>eeibcly &lt;brendan.cleary@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1435701298000</long>
      </object>
     </void>
     <void property="message">
      <string>Updated postinstall to remove JBOSS start - already in jbossconfig
    
    Change-Id: I4f44c2ed5b37fd906585b58e7d734184c604a63f</string>
     </void>
     <void property="revision">
      <string>bbb56d68</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Ciaran Kelly &lt;eeiciky@eselivm2v205l.lmera.ericsson.se&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1429015984000</long>
      </object>
     </void>
     <void property="message">
      <string>Update postInstall.sh to configure access on AP dirs
    
    Change-Id: Ic1565aa7e02d322cf81c53f31575d7cd96f46da9</string>
     </void>
     <void property="revision">
      <string>0c112a36</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Ciaran Kelly &lt;eeiciky@eselivm2v205l.lmera.ericsson.se&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1428918267000</long>
      </object>
     </void>
     <void property="message">
      <string>Update postInstall.sh to start jboss service
    
    Change-Id: If9633d6bc06fa826b78709b8495607486ea4856f</string>
     </void>
     <void property="revision">
      <string>083e24df</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>eeiciky &lt;ciaran.kelly@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1428668250000</long>
      </object>
     </void>
     <void property="message">
      <string>Add global properties for apserv remote connection, add remote connection to mscm
    
    Change-Id: I0953404a001a0a21ecd46a31c6115df7c101b3a9</string>
     </void>
     <void property="revision">
      <string>63045f90</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>ebrigun &lt;brian.gunning@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1422400314000</long>
      </object>
     </void>
     <void property="message">
      <string>updating selinux settings
    
    Change-Id: I782d4db949f5c7b5f5dd9639953565ca70a9af90</string>
     </void>
     <void property="revision">
      <string>108f2835</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>eseabyr &lt;sean.byrne@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1419001387000</long>
      </object>
     </void>
     <void property="message">
      <string>Adding Service-Group-RPM-Archetype
    
    Change-Id: I2e5a05277598f1295cb445d09abb2c81c8e0be5b</string>
     </void>
     <void property="revision">
      <string>aecc7a09</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
