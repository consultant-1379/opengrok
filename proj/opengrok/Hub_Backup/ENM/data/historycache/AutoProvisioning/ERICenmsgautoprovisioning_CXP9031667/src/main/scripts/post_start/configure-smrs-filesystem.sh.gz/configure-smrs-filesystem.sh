<?xml version="1.0" encoding="UTF-8"?>
<java version="1.7.0_241" class="java.beans.XMLDecoder">
 <object class="org.opensolaris.opengrok.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>equiric &lt;ricky.quillinan@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1589545643000</long>
      </object>
     </void>
     <void property="message">
      <string>TORF-430757 Adding missing global variable to SMRS script
    
    Change-Id: I0ae12bb3286d6f543895a4df40253625a101f3b2</string>
     </void>
     <void property="revision">
      <string>da01b1ac</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>ezlevge &lt;george.l.levogiannis@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1535672219000</long>
      </object>
     </void>
     <void property="message">
      <string>TORF-292619 Changes required in &apos;configure-smrs-filesystem.sh&apos; script in SGs
    
    Change-Id: I28b2edd014950cd9d5006cb03e0d101666a66351</string>
     </void>
     <void property="revision">
      <string>ccd3b380</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>xghumdg &lt;ghulam.ghaus@tcs.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1466592060000</long>
      </object>
     </void>
     <void property="message">
      <string>TORF-106122 SMRS changes for MINI-LINK Indoor SW upgrade
    
    Change-Id: Id9016d774233242faf3afa024c7d11261b733837</string>
     </void>
     <void property="revision">
      <string>d1b552a5</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>xgansre &lt;g.sreeram@tcs.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1447325354000</long>
      </object>
     </void>
     <void property="message">
      <string>TORF-82822 Replace Networktype LRAN with &quot;smrsroot&quot; configuration
    parameter in SMRS Directory Structure
    http://jira-nam.lmera.ericsson.se/browse/TORF-82822
    -Are there any dependent or new rpm?s: Yes, All AP,SHM &amp; SECURITY sg
    should be delivered at once
    -List dependent code reviews: N/A
    -Is backwards compatible change:  No
    -State level of testing completed: Cracked ISO
    
    Change-Id: Icc5b53722a5fbd7043353aac087feaf4836d1198</string>
     </void>
     <void property="revision">
      <string>88ab9bc7</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>xgansre &lt;g.sreeram@tcs.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1446549888000</long>
      </object>
     </void>
     <void property="message">
      <string>TORF-83120 SFTP Failing During ENM Upgrade
    http://jira-nam.lmera.ericsson.se/browse/TORF-83120
    -Are there any dependent or new rpm?s: Yes, All AP,SHM &amp; SECURITY sg
    should be delivered at once
    -List dependent code reviews: N/A
    -Is backwards compatible change:  No
    -State level of testing completed: Cracked ISO
    
    Change-Id: Ib2b5a17dfa2b5738f24482a519fdc91f38054591</string>
     </void>
     <void property="revision">
      <string>a179550f</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>xgansre &lt;g.sreeram@tcs.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1445973835000</long>
      </object>
     </void>
     <void property="message">
      <string>TORF-69800 SMRS directory creation script cleanup from SG
    http://jira-nam.lmera.ericsson.se/browse/TORF-69800
    -Are there any dependent or new rpm?s: Yes, All AP,SHM &amp; SECURITY sg
    should be delivered at once
    -List dependent code reviews: N/A
    -Is backwards compatible change:  No
    -State level of testing completed: Cracked ISO
    
    Change-Id: Ie8fd1e884c598d4844977fffe038153eddceec58</string>
     </void>
     <void property="revision">
      <string>0f377617</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Sreeram Ganta &lt;g.sreeram@tcs.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1445850046000</long>
      </object>
     </void>
     <void property="message">
      <string>Revert &quot;TORF-69800 SMRS directory creation script cleanup from SG&quot;
    
    This reverts commit 0f57204da18e622b983063fda496d0aceb2b8e20.
    
    Change-Id: Id6e9a929f71a51e0c8a1979a2002ac8ebfe9493a</string>
     </void>
     <void property="revision">
      <string>74069f8a</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>xgansre &lt;g.sreeram@tcs.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1444070908000</long>
      </object>
     </void>
     <void property="message">
      <string>TORF-69800 SMRS directory creation script cleanup from SG
    
    http://jira-nam.lmera.ericsson.se/browse/TORF-69800
    
    -Are there any dependent or new rpm?s: Yes, All AP,SHM &amp; SECURITY sg should be
    delivered at once. Secserv sg gerrit review link https://gerrit.ericsson.se/#/c/875067
    -List dependent code reviews: N/A
    -Is backwards compatible change:  No
    -State level of testing completed: Cracked ISO
    
    Change-Id: I3a526f957c00fafc5b2733eefa90182d804ed135</string>
     </void>
     <void property="revision">
      <string>0f57204d</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>xgotuda &lt;gottumukkala.deepthi@tcs.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1445351784000</long>
      </object>
     </void>
     <void property="message">
      <string>TORF-55644 New directory inside SMRS for the upgrade independence
    
    http://jira-nam.lmera.ericsson.se/browse/TORF-55644
    
    Team Name:Zenith
    Are there any dependent or new rpms?: Security SG , SHM SG
    List dependent code reviews: Security SG , SHM SG
    Is backwards compatible change: Yes State level of testing completed: Maintrack full RFA
    Is your delivery imminent: Yes, 15.15
    
    Change-Id: Ib7278a39e376c047b0b3cb0026b100fe4a7da365</string>
     </void>
     <void property="revision">
      <string>4cb2f00b</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>eniahal &lt;niall.hallahan@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1438702475000</long>
      </object>
     </void>
     <void property="message">
      <string>[TORF-66675] Update how ap configures filesystem http://jira-nam.lmera.ericsson.se/browse/TORF-66675
    
    Change-Id: I5c48b568f4878bda22da20aed479a9f1d624b080</string>
     </void>
     <void property="revision">
      <string>443b0c78</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Tao Jiang T &lt;tao.t.jiang@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1438266868000</long>
      </object>
     </void>
     <void property="message">
      <string>Revert &quot;[TORF-66675] Update how ap configures it&apos;s file smrs filesystem http://jira-nam.lmera.ericsson.se/browse/TORF-66675&quot;
    
    Should commit in sprint 15.12
    This reverts commit e97b41256ef14aec80210d93bac2d55bdd25dfe8.
    
    Change-Id: Iba40c7b439826c8d056490d830a2319c6f88d7e0</string>
     </void>
     <void property="revision">
      <string>1e05956b</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>eniahal &lt;niall.hallahan@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1438238935000</long>
      </object>
     </void>
     <void property="message">
      <string>[TORF-66675] Update how ap configures it&apos;s file smrs filesystem http://jira-nam.lmera.ericsson.se/browse/TORF-66675
    
    Change-Id: I2138bf4acddb80559ea843e4fd300b2b9b536cd7</string>
     </void>
     <void property="revision">
      <string>e97b4125</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>eeiciky &lt;ciaran.kelly@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1429613069000</long>
      </object>
     </void>
     <void property="message">
      <string>Add script to configure smrs filesystem
    
    Change-Id: I877a08c017497cea07b2eb18237ac70d671c991f</string>
     </void>
     <void property="revision">
      <string>2b807ed0</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
