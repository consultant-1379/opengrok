<?xml version="1.0" encoding="UTF-8"?>
<java version="1.7.0_99" class="java.beans.XMLDecoder">
 <object class="org.opensolaris.opengrok.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vignesh Kumar NK &lt;vignesh.kumar.n.k@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1553514271000</long>
      </object>
     </void>
     <void property="message">
      <string>[TORF-328497] 5GB RAM 437: apserv cleanstart from 1.70.131 to 1.71.28
    https://jira-nam.lmera.ericsson.se/browse/TORF-328497
    https://jira-nam.lmera.ericsson.se/browse/TORF-336088
    
    Change-Id: I80b417b1ebb3b4590d5bfa1650365c8ea00056ed</string>
     </void>
     <void property="revision">
      <string>8b020785</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Anuj Sharma F &lt;anuj.f.sharma@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1553074749000</long>
      </object>
     </void>
     <void property="message">
      <string>Revert &quot;TORF-329590 for 19.04 dropback - Set redhat overcommit attributes to prevent processes on memory overcommitment&quot;
    
    This reverts commit 0db24b169601e468af42ed091fc4a85a7c335dd5.
    
    Change-Id: Ibddf8ce4391faf1c7e177f9a4636a6929bc8af94</string>
     </void>
     <void property="revision">
      <string>7015a455</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>eaajssa &lt;anuj.f.sharma@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1552579210000</long>
      </object>
     </void>
     <void property="message">
      <string>TORF-329590 Set redhat overcommit attributes to prevent processes on memory overcommitment
    
    Change-Id: If2297cf58e1d26cf57d47d0f95bff5458a31389d</string>
     </void>
     <void property="revision">
      <string>0db24b16</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vignesh &lt;vignesh.kumar.n.k@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1539190188000</long>
      </object>
     </void>
     <void property="message">
      <string>[TORF-298221] RV:apserv recorded cleanstart during Upgrade on 5299 to 1.63.121(18.14)
    https://jira-nam.lmera.ericsson.se/browse/TORF-298221
    
    Change-Id: I6668bcdbd6d509df694c07edcce29cd88504bdfd</string>
     </void>
     <void property="revision">
      <string>ab561dc0</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
