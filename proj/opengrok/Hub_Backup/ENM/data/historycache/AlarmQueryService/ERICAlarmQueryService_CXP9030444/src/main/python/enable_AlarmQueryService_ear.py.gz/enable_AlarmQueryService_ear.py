<?xml version="1.0" encoding="UTF-8"?>
<java version="1.7.0_241" class="java.beans.XMLDecoder">
 <object class="org.opensolaris.opengrok.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>ealdqua &lt;aldo.quaranta@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1592836076000</long>
      </object>
     </void>
     <void property="message">
      <string>[TORF-394083] - Update CXP : Alarm Query Service to SFWK 4, EAP 7.2 and JEE 8
    
    Change-Id: If2a29bf80e849c032b3420960e86870b45d003df</string>
     </void>
     <void property="revision">
      <string>e8eda264</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
