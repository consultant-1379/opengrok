<?xml version="1.0" encoding="UTF-8"?>
<java version="1.7.0_99" class="java.beans.XMLDecoder">
 <object class="org.opensolaris.opengrok.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>xpissas &lt;sasanka.pisipati@tcs.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1407927184000</long>
      </object>
     </void>
     <void property="message">
      <string>RPM POM changes</string>
     </void>
     <void property="revision">
      <string>cd8d78cc</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
