<?xml version="1.0" encoding="UTF-8"?>
<java version="1.7.0_99" class="java.beans.XMLDecoder">
 <object class="org.opensolaris.opengrok.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opensolaris.opengrok.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>echmara &lt;marasani.chandu@ericsson.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1471010803000</long>
      </object>
     </void>
     <void property="message">
      <string>[TORF-75750] : As a user of Alarm routing to email ,emails should be sent in secured way.
    https://jira-nam.lmera.ericsson.se/browse/TORF-75750
    
    Change-Id: I1619333858a142b62ceeb95ea82bed47dc7ef47d
    Signed-off-by: xsrieru &lt;srikanth.eruvanti@tcs.com&gt;</string>
     </void>
     <void property="revision">
      <string>ecd0b8d7</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
